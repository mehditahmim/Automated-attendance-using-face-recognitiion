package com.example.frontend.APIManager;

public class InsideAttendanceAPI {
}
